KR STORE — BLACK & GOLD APP PACKAGE

ANDROID PHONE INSTALL (PWA)
1. Upload ALL files in this folder to your existing Netlify site, replacing the current index.html and adding manifest.webmanifest, sw.js and icon.svg.
2. Open https://krstoreglobal.netlify.app in Chrome on Android.
3. Tap Chrome menu (three dots) > Install app (or Add to Home screen) > Install.
4. KR Store will appear on the phone as an app icon.

GOOGLE PLAY STORE
This package is a Progressive Web App (PWA) and includes the website assets needed for install on Android. It is NOT a signed Android APK or Play Store AAB. Google Play publication requires an Android wrapper/build, signing key, Play Console developer account, store listing, privacy policy and compliance review. A Play Console account has a registration fee; check Google's current requirements and fee before registering.

The website is an affiliate product-discovery store. Retailers handle checkout, payment, delivery and returns.
